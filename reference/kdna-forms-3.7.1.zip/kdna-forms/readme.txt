=== KDNA Forms ===
Contributors: krulldna
Tags: forms, contact form, form builder, payments, elementor
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.7.1
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Powerful form builder for WordPress. Create contact forms, surveys, quizzes, and more with an intuitive drag-and-drop interface. Includes reCAPTCHA protection and Elementor integration.

== Description ==

KDNA Forms is a drag-and-drop form builder for WordPress. Build contact forms, surveys, quizzes, file upload forms and paid forms, send notifications with uploaded files attached or linked, protect submissions with reCAPTCHA, and style every part of a form from the KDNA Forms Elementor widget.

Feed add-ons connect forms to ActiveCampaign, Campaign Monitor, Flodesk, HubSpot, Kit, Klaviyo, Mailchimp and Salesforce, and the Stripe add-on takes one-off and recurring card payments.

Updates are delivered automatically from KDNA Updates.

== Changelog ==

= 3.7.1 =
* Updated the KDNA Update Client to 1.1.0: automatic updates are now switched on or off on each site with WordPress's own Enable/Disable auto-updates link

= 3.7.0 =
* Added automatic updates via KDNA Updates

= 3.6.2 =
* Fixed: the Select Files button did nothing when Enable Multi-File Upload was switched on
* Fixed: the card type highlight on the credit card field never activated
* Fixed: delete controls on files already uploaded did not match those on new uploads

= 3.6.1 =
* Fixed: a fatal error on the entry detail screen when reCAPTCHA was enabled
* Fixed: two further reCAPTCHA calls that could stop a submission with a fatal error
* Fixed: the reCAPTCHA score was never saved to the entry

= 3.6.0 =
* Added an icon to the submit button in the Elementor widget, placed before or after the label, with rotate, slide and grow hover animations

= 3.5.10 =
* Fixed: the Elementor submit button text colour did not apply when a global colour was chosen
* Fixed: 24 Elementor style selectors that could never match the form

= 3.5.9 =
* Fixed: a card could be charged when the form failed validation, leaving no entry and sending no notification
* Uncaptured card authorisations are now released when a submission is rejected

= 3.5.8 =
* Fixed: a field dragged into the form builder jumped to the top instead of staying where it was dropped

= 3.5.7 =
* Fixed: a fatal error opening a payment feed's settings while any feed add-on was active

= 3.5.6 =
* Fixed: every paid submission failed with a server error

= 3.5.5 =
* Payment failures are now written to the PHP error log when the Logging add-on is not installed

= 3.5.4 =
* Fixed: the original price was not struck through when an early bird price applied
* Payment failures now report their reason

= 3.5.3 =
* Fixed: payments were not authorised during validation, so a charged card could leave the entry unpaid

= 3.5.2 =
* Fixed: the form editor failed to load three script files after the rename

= 3.5.1 =
* Added the payment framework support the Stripe add-on needs, including the subscription lifecycle

= 3.5.0 =
* Completed the rename of the remaining internal identifiers

= 3.4.4 =
* Reinstated the uppercase identifier rename once the Save button fault was traced elsewhere

= 3.4.3 =
* Fixed: the form editor's Save button did not respond, because the conditional logic panel sat over it

= 3.4.2 =
* Restored the working form editor by reverting the uppercase and constant renames

= 3.4.1 =
* Applied the kforms naming consistently

= 3.4.0 =
* Renamed uppercase class names, constants and JavaScript globals

= 3.3.0 =
* Renamed the remaining name segments, fonts, file names and branding

= 3.2.0 =
* Renamed the form theme slug and the block editor block

= 3.1.0 =
* Renamed the hyphenated class families in rendered forms

= 3.0.0 =
* Renamed hook names and the classes and ids in rendered form markup

= 2.11.0 =
* Renamed request field names and the matching stylesheet selectors

= 2.10.0 =
* Renamed the internal PHP and JavaScript identifiers

= 2.9.1 =
* Fixed: the Save button stopped working after admin screen class names were changed; those changes were withdrawn

= 2.9.0 =
* Merged identifiers that existed under two names

= 2.8.1 =
* Removed a duplicate close icon from the conditional logic panel

= 2.8.0 =
* Restored the conditional logic setup from 2.4.2 while keeping later fixes

= 2.7.2 =
* Fixed the remaining mismatched names between the plugin's scripts and its pages

= 2.7.1 =
* Fixed: form editor settings could not load their text strings
* Fixed: the form editor sidebar ran past the bottom of the screen

= 2.7.0 =
* Restored the container the conditional logic panel attaches to

= 2.6.2 =
* Fixed: an error when opening settings for some field types

= 2.6.1 =
* Moved conditional logic into its own section of the field settings

= 2.6.0 =
* Conditional logic settings returned to the field settings panel

= 2.5.0 =
* Fixed every mismatched setting name found by audit

= 2.4.2 =
* Fixed six more settings that were saved under one name and read under another

= 2.4.1 =
* Fixed: conditional logic did not apply on the front end

= 2.4.0 =
* Conditional logic now applies as soon as the form loads

= 2.3.3 =
* Conditional logic is applied even if form setup does not finish

= 2.3.2 =
* Forms using conditional logic are always shown, even if form setup does not finish

= 2.3.1 =
* Fixed: forms inside Elementor popups did not initialise

= 2.3.0 =
* Rebuilt the conditional logic panel

= 2.2.2 =
* Fixed: the conditional logic panel was cut off by the editor layout

= 2.2.1 =
* Fixed: the conditional logic panel was covered by the form preview

= 2.2.0 =
* Conditional logic now opens in a panel beside the field settings

= 2.1.1 =
* Fixed: conditional logic settings did not appear

= 2.1.0 =
* Restored the payment framework that payment add-ons need

= 2.0.0 =
* Removed files not needed at runtime and duplicate files

= 1.2.0 =
* Maintenance release

= 1.0.0 =
* First release of KDNA Forms
