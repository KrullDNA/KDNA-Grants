var kresultsAjaxRequest;

var kresults = {

    drawCharts: function () {
        var containers = jQuery('.kresults-chart-wrapper');
        containers.each(function (index, elem) {
            var id = jQuery(elem).attr('id');
            var options = jQuery(elem).data('options');
            var datatable = jQuery(elem).data('datatable');
            var chartType = jQuery(elem).data('charttype');
            var data_array = datatable;
            var data = google.visualization.arrayToDataTable(data_array);
            var cont = document.getElementById(id);
            var chart;
            if (chartType == "bar") {
                chart = new google.visualization.BarChart(cont);
            } else if (chartType == "pie") {
                chart = new google.visualization.PieChart(cont);
            } else if (chartType == "column") {
                chart = new google.visualization.ColumnChart(cont);
            }
            chart.draw(data, options);
        });

		// For RTL languages, set the text-anchor of bar chart labels to "start" to keep proper alignment.
		const isRTL   = document.documentElement.dir === 'rtl';
		const isResultsWrapper = document.querySelector('.kresults-chart-wrapper svg')
		if (isResultsWrapper && isRTL) {
			document.querySelectorAll('text[text-anchor="end"]').forEach(function(el) {
				el.setAttribute('text-anchor', 'start');
			})
		}
    },

    renderStateData: function (state) {
        var results = jQuery("#kresults-results");
        results.data('searchcriteria', state.searchCriteria);
        jQuery("#kresults-results-filter").html(state.filterUI);
        results.css('opacity', 0);
        results.html(state.html);
        kresults.drawCharts();
        results.fadeTo("slow", 1);

        var filterContainer = jQuery("#kresults-results-field-filters-container");
        filterContainer.resizable();
        filterContainer.resizable('destroy');
        filterContainer.resizable({
            handles: 's'
        });
    },

    getResults: function () {
        kresults.recordFormState();
        var kresultsData = jQuery('#kresults-results-filter-form').serialize();
        kresults.sendRequest(kresultsData)
    },

    sendRequest: function (kresultsData, serverStateObject, checkSum) {
        var results = jQuery("#kresults-results");
        var filterButtons = jQuery("#kresults-results-filter-buttons input");
        var viewSlug = jQuery("#kresults-view-slug").val();
		var nonce = jQuery("#_kdna_results_nonce").val()
        var data_str = "action=kresults_get_results_" + viewSlug + "&" + kresultsData + '&_kdna_results_nonce' + nonce ;
        if (serverStateObject)
            data_str += "&state=" + serverStateObject + "&checkSum=" + checkSum;

        kresultsAjaxRequest = jQuery.ajax({
            url       : ajaxurl,
            type      : 'POST',
            dataType  : 'json',
            data      : data_str,
            beforeSend: function (xhr, opts) {
                results.fadeTo("slow", 0.33);
                results.html('');
                kform.utils.trigger( { event: 'kform/page_loader/show' } );
                filterButtons.attr('disabled', 'disabled');
            }
        })
        .done(function (response) {
            if (!response || response === -1) {
                kform.utils.trigger( { event: 'kform/page_loader/hide' } );
                results.html(kresultsStrings.ajaxError);
            } else {
                if (response.status === "complete") {
                    filterButtons.removeAttr('disabled');
                    kform.utils.trigger( { event: 'kform/page_loader/hide' } );
                    results.html(response.html);
                    jQuery("#kresults-results").data('searchcriteria', response.searchCriteria); //used in 'more' links

                    var filterUI = jQuery("#kresults-results-filter").html();

                    kresults.drawCharts();
                    results.fadeTo("slow", 1);
                    if (window.history.replaceState) {
                        if (!history.state) {
                            history.replaceState({"html": response.html, "filterUI": filterUI, "searchCriteria": response.searchCriteria}, "", "?" + kresultsData);
                        } else {
                            history.pushState({"html": response.html, "filterUI": filterUI, "searchCriteria": response.searchCriteria}, "", "?" + kresultsData);
                        }
                    }
                    kresults.drawCharts();
                    if (window["kdnaform_initialize_tooltips"])
                        kdnaform_initialize_tooltips();
                } else if (response.status === "incomplete") {
                    serverStateObject = response.stateObject;
                    kresults.sendRequest(kresultsData, serverStateObject, response.checkSum);
                    results.html(response.html);
                } else {
                    kform.utils.trigger( { event: 'kform/page_loader/hide' } );
                    results.html(kresultsStrings.ajaxError);
                }
            }
        })
        .fail(function (error) {
            filterButtons.removeAttr('disabled');
            results.fadeTo("fast", 1);
            var msg = error.statusText;
            kform.utils.trigger( { event: 'kform/page_loader/hide' } );
            if (msg == "abort") {
                msg = "Request cancelled";
            } else {
                msg = kresultsStrings.ajaxError;
            }
            results.html(msg);
        })
    },

    getMoreResults: function (formId, fieldId) {
        var container = jQuery('#kresults-results-field-content-' + fieldId),
            results = jQuery("#kresults-results"),
            offset = jQuery(container).data('offset'),
            viewSlug = jQuery("#kresults-view-slug").val(),
            searchCriteria = results.data('searchcriteria'),
            nonce = jQuery("#_kdna_results_nonce").val();

        jQuery.ajax({
            url     : ajaxurl,
            type    : 'POST',
            dataType: 'json',
            data    : {
                action: 'kresults_get_more_results_' + viewSlug,
                view: viewSlug,
                form_id: formId,
                field_id: fieldId,
                offset: offset,
                search_criteria: searchCriteria,
                _kdna_results_nonce: nonce
            },
            success : function (response) {
                if (response === -1) {
                    //permission denied
                }
                else {
                    if (response.html)
                        jQuery(container).append(response.html);
                    if (!response.more_remaining)
                        jQuery('#kresults-results-field-more-link-' + fieldId).hide();

                    jQuery(container).data('offset', response.offset);
                }
            }
        });

        return false;

    },

    clearFilterForm: function () {
        jQuery("#kresults-results-field-filters-container").off('click', '.kform-add').kdnaFilterUI(kresultsFilterSettings, [], true);
        jQuery('#kresults-results-filter-form').find('input, select').each(function () {
            switch (this.type) {
                case 'text':
                case 'select-one':
                    jQuery(this).val('').change();
                    break;
                case 'checkbox':
                case 'radio':
                    this.checked = false;
            }
        });
    },

    recordFormState: function () {
        jQuery("#kresults-results-filter-form input[type='radio']").each(function () {
            if (this.checked) {
                jQuery(this).prop("defaultChecked", true);
            } else {
                jQuery(this).prop("defaultChecked", false);
            }
        });
        jQuery("#kresults-results-filter-form input[type='checkbox']").each(function () {
            if (this.checked) {
                jQuery(this).prop("defaultChecked", true);
            } else {
                jQuery(this).prop("defaultChecked", false);
            }
        });
        jQuery("#kresults-results-filter-form input[type='text']").each(function () {
            jQuery(this).prop("defaultValue", jQuery(this).val());
        });
        jQuery("#kresults-results-filter-form select option").each(function () {
            jQuery(this).prop("defaultSelected", jQuery(this).prop('selected'));
        });
    },

    setCustomFilter: function(key, value){
        elementId = "kresults-custom-" + key;
        if(jQuery('#' + elementId).length == 0)
            jQuery('#kresults-results-filter-form').append("<input type='hidden' id='" + elementId + "' name='" + key + "' value='" + value + "'>");
        else
            jQuery('#' + elementId).val(value);
    }

};

google.load('visualization', '1', {packages: ['corechart']});
google.setOnLoadCallback(kresults.drawCharts);


jQuery( window ).on( 'load', function () {

    if (jQuery("#kresults-results").length > 0) {

        jQuery("#kresults-results-field-filters-container").kdnaFilterUI(kresultsFilterSettings, kresultsInitVars, true);
        var $window = jQuery(window);

         $window.resize(function (e) {
         if (e.target === window) {
             kresults.drawCharts();
             }
         });

        window.onpopstate = function (e) {
            if (e.state)
                kresults.renderStateData(e.state)
        };


        jQuery("#kresults-results-filter-date-start, #kresults-results-filter-date-end").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true});

        jQuery('.ui-datepicker-trigger').on('click', function() {
            jQuery(this).parent().find('input').datepicker( 'show' );
        });

        jQuery("#kresults-results-filter-form").submit(function (e) {
            kresults.getResults();
            return false;
        });

        // Ensure we only treat a state as valid if it contains our expected data.
        const initialState = history.state;
        const hasGResultsState = initialState && typeof initialState === 'object' && ( 'html' in initialState ) && ( 'searchCriteria' in initialState );

        if ( hasGResultsState ) {
            kresults.renderStateData( initialState );
        } else {
            kresults.getResults();
        }

        if (window["kdnaform_initialize_tooltips"])
            kdnaform_initialize_tooltips();

    }
});
