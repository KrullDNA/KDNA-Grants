<?php

namespace KDNA_Forms\KDNA_Forms\Query\JSON_Handlers;

/**
 * KDNA_JSON_Handler implementation which uses a MySQL "LIKE" query. Not as performant as JSON_CONTAINS, but
 * available on older (pre-5.7) versions of MySQL.
 *
 * @since 2.7
 */
class KDNA_String_JSON_Handler extends KDNA_JSON_Handler {

	public function query( $slug ) {
		global $wpdb;

		$setting_name   = $this->get_setting_name();
		$like_statement = sprintf( '%%"%s":"%s"%%', $setting_name, $slug );
		$query          = "SELECT form_id FROM {$wpdb->prefix}gf_form_meta AS meta LEFT JOIN {$wpdb->prefix}gf_form AS form ON form.id = meta.form_id WHERE is_trash = 0 AND is_active = 1 AND display_meta LIKE %s";
		$prepared_query = $wpdb->prepare( $query, $like_statement ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		return $wpdb->get_var( $prepared_query ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
	}

}