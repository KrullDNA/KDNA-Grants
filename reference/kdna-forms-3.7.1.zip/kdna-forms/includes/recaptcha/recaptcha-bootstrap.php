<?php
/**
 * KDNA Forms reCAPTCHA Bootstrap
 *
 * Loads and registers the reCAPTCHA integration as a built-in feature.
 *
 * @package KDNA_Forms
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die();
}

add_action( 'kdnaform_loaded', 'kdna_recaptcha_load', 5 );

function kdna_recaptcha_load() {
	if ( ! method_exists( 'KDNAAddOn', 'register' ) ) {
		return;
	}

	require_once dirname( __FILE__ ) . '/class-kdna-recaptcha.php';

	KDNAAddOn::register( 'KDNA_Forms\KDNA_Forms_RECAPTCHA\KDNA_Recaptcha' );
}

/**
 * The reCAPTCHA add-on instance.
 *
 * class-recaptcha-api.php calls this three times — for log_debug(), log_error()
 * and maybe_decode_json() — and nothing defined it, so every one of those lines
 * was a fatal waiting on whichever request reached it first. The calls sit
 * inside the KDNA_Forms\KDNA_Forms_RECAPTCHA namespace, but PHP falls back to
 * the global namespace for an unqualified function, so defining it here in the
 * global namespace is what those calls resolve to.
 *
 * @since 3.6.1
 *
 * @return \KDNA_Forms\KDNA_Forms_RECAPTCHA\KDNA_Recaptcha
 */
function kdna_recaptcha() {
	return \KDNA_Forms\KDNA_Forms_RECAPTCHA\KDNA_Recaptcha::get_instance();
}
