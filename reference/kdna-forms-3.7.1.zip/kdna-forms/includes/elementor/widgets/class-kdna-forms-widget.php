<?php
/**
 * KDNA Forms Elementor Widget
 *
 * Comprehensive Elementor widget with full styling options for KDNA Forms.
 * Works with Elementor popups.
 *
 * @package KDNA_Forms
 * @subpackage Elementor
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KDNA_Forms_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'kdna-forms';
	}

	public function get_title() {
		return esc_html__( 'KDNA Form', 'kdnaforms' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return array( 'kdna-forms', 'general' );
	}

	public function get_keywords() {
		return array( 'form', 'contact', 'kdna', 'survey', 'quiz' );
	}

	/**
	 * Get available forms for the dropdown.
	 */
	private function get_forms_list() {
		global $wpdb;
		$forms = array( '' => esc_html__( '-- Select a Form --', 'kdnaforms' ) );
		$table = $wpdb->prefix . 'gf_form';

		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {
			$results = $wpdb->get_results( "SELECT id, title FROM {$table} WHERE is_active = 1 AND is_trash = 0 ORDER BY title ASC" );
			if ( $results ) {
				foreach ( $results as $form ) {
					$forms[ $form->id ] = $form->title;
				}
			}
		}

		return $forms;
	}

	protected function register_controls() {
		$this->register_content_controls();
		$this->register_style_form_container();
		$this->register_style_title();
		$this->register_style_description();
		$this->register_style_labels();
		$this->register_style_sub_labels();
		$this->register_style_inputs();
		$this->register_style_textarea();
		$this->register_style_select();
		$this->register_style_checkbox_radio();
		$this->register_style_image_choice();
		$this->register_style_file_upload();
		$this->register_style_section_break();
		$this->register_style_submit_button();
		$this->register_style_submit_icon();
		$this->register_style_prev_next_buttons();
		$this->register_style_validation();
		$this->register_style_progress_bar();
		$this->register_style_confirmation();
		$this->register_style_field_spacing();
	}

	// ==========================================
	// CONTENT TAB
	// ==========================================

	private function register_content_controls() {
		$this->start_controls_section( 'section_form', array(
			'label' => esc_html__( 'Form Settings', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		) );

		$this->add_control( 'form_id', array(
			'label'   => esc_html__( 'Select Form', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => $this->get_forms_list(),
			'default' => '',
		) );

		$this->add_control( 'show_title', array(
			'label'        => esc_html__( 'Show Title', 'kdnaforms' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'default'      => 'yes',
			'label_on'     => esc_html__( 'Yes', 'kdnaforms' ),
			'label_off'    => esc_html__( 'No', 'kdnaforms' ),
			'return_value' => 'yes',
		) );

		$this->add_control( 'show_description', array(
			'label'        => esc_html__( 'Show Description', 'kdnaforms' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'default'      => 'yes',
			'label_on'     => esc_html__( 'Yes', 'kdnaforms' ),
			'label_off'    => esc_html__( 'No', 'kdnaforms' ),
			'return_value' => 'yes',
		) );

		$this->add_control( 'use_ajax', array(
			'label'        => esc_html__( 'AJAX Submission', 'kdnaforms' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'default'      => 'yes',
			'label_on'     => esc_html__( 'Yes', 'kdnaforms' ),
			'label_off'    => esc_html__( 'No', 'kdnaforms' ),
			'return_value' => 'yes',
		) );

		$this->add_control( 'tab_index', array(
			'label'   => esc_html__( 'Tab Index Start', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::NUMBER,
			'default' => 0,
			'min'     => 0,
		) );

		// Theme selector removed - forms are styled via Elementor widget controls.

		$this->add_control( 'custom_class', array(
			'label'       => esc_html__( 'Custom CSS Class', 'kdnaforms' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => '',
			'description' => esc_html__( 'Add a custom CSS class to the form wrapper.', 'kdnaforms' ),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - FORM CONTAINER
	// ==========================================

	private function register_style_form_container() {
		$this->start_controls_section( 'section_style_container', array(
			'label' => esc_html__( 'Form Container', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Background::get_type(), array(
			'name'     => 'container_background',
			'types'    => array( 'classic', 'gradient' ),
			'selector' => '{{WRAPPER}} .kdna-elementor-form-wrapper',
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'container_border',
			'selector' => '{{WRAPPER}} .kdna-elementor-form-wrapper',
		) );

		$this->add_responsive_control( 'container_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kdna-elementor-form-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'container_box_shadow',
			'selector' => '{{WRAPPER}} .kdna-elementor-form-wrapper',
		) );

		$this->add_responsive_control( 'container_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em', '%' ),
			'selectors'  => array(
				'{{WRAPPER}} .kdna-elementor-form-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'container_margin', array(
			'label'      => esc_html__( 'Margin', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em', '%' ),
			'selectors'  => array(
				'{{WRAPPER}} .kdna-elementor-form-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'container_max_width', array(
			'label'      => esc_html__( 'Max Width', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%', 'vw' ),
			'range'      => array(
				'px' => array( 'min' => 200, 'max' => 1600 ),
				'%'  => array( 'min' => 10, 'max' => 100 ),
				'vw' => array( 'min' => 10, 'max' => 100 ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kdna-elementor-form-wrapper' => 'max-width: {{SIZE}}{{UNIT}}; margin-left: auto; margin-right: auto;',
			),
		) );

		$this->add_control( 'global_colors_heading', array(
			'label'     => esc_html__( 'Global Colors', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
		) );

		$this->add_control( 'global_focus_color', array(
			'label'       => esc_html__( 'Focus Color', 'kdnaforms' ),
			'type'        => \Elementor\Controls_Manager::COLOR,
			'description' => esc_html__( 'Border and outline color when inputs are focused. Important for keyboard accessibility.', 'kdnaforms' ),
			'selectors'   => array(
				'{{WRAPPER}} .kform_wrapper' => '--kdna-ctrl-border-color-focus: {{VALUE}}; --kdna-ctrl-outline-color-focus: rgba({{VALUE}}, 0.3);',
				'{{WRAPPER}} .kform_wrapper input:focus, {{WRAPPER}} .kform_wrapper textarea:focus, {{WRAPPER}} .kform_wrapper select:focus' => 'border-color: {{VALUE}} !important; outline-color: {{VALUE}} !important;',
			),
		) );

		$this->add_responsive_control( 'global_focus_width', array(
			'label'       => esc_html__( 'Focus Border Width', 'kdnaforms' ),
			'type'        => \Elementor\Controls_Manager::SLIDER,
			'size_units'  => array( 'px' ),
			'range'       => array( 'px' => array( 'min' => 2, 'max' => 10 ) ),
			'default'     => array( 'size' => 2, 'unit' => 'px' ),
			'description' => esc_html__( 'Width of the focus outline. Minimum 2px for WCAG accessibility compliance.', 'kdnaforms' ),
			'selectors'   => array(
				'{{WRAPPER}} .kform_wrapper' => '--kdna-ctrl-outline-width-focus: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .kform_wrapper input:focus, {{WRAPPER}} .kform_wrapper textarea:focus, {{WRAPPER}} .kform_wrapper select:focus' => 'outline-width: {{SIZE}}{{UNIT}} !important;',
			),
		) );

		$this->add_control( 'global_accent_color', array(
			'label'       => esc_html__( 'Accent Color', 'kdnaforms' ),
			'type'        => \Elementor\Controls_Manager::COLOR,
			'description' => esc_html__( 'Color for checked checkboxes, radio buttons, and selected image choices.', 'kdnaforms' ),
			'selectors'   => array(
				'{{WRAPPER}} .kform_wrapper' => '--kdna-color-primary: {{VALUE}}; --kdna-ctrl-accent-color: {{VALUE}}; --kdna-color-in-ctrl-primary: {{VALUE}};',
				'{{WRAPPER}} .kform_wrapper input[type="checkbox"]:checked, {{WRAPPER}} .kform_wrapper input[type="radio"]:checked' => 'accent-color: {{VALUE}} !important;',
				'{{WRAPPER}} .kfield--type-image_choice .kchoice:has(input:checked)::after' => 'background-color: {{VALUE}} !important;',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - TITLE
	// ==========================================

	private function register_style_title() {
		$this->start_controls_section( 'section_style_title', array(
			'label'     => esc_html__( 'Title', 'kdnaforms' ),
			'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
			'condition' => array( 'show_title' => 'yes' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'title_typography',
			'selector' => '{{WRAPPER}} .kform_heading .kform_title',
		) );

		$this->add_control( 'title_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_heading .kform_title' => 'color: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'title_alignment', array(
			'label'   => esc_html__( 'Alignment', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => array(
				'left'   => array( 'title' => esc_html__( 'Left', 'kdnaforms' ), 'icon' => 'eicon-text-align-left' ),
				'center' => array( 'title' => esc_html__( 'Center', 'kdnaforms' ), 'icon' => 'eicon-text-align-center' ),
				'right'  => array( 'title' => esc_html__( 'Right', 'kdnaforms' ), 'icon' => 'eicon-text-align-right' ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kform_heading .kform_title' => 'text-align: {{VALUE}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Text_Shadow::get_type(), array(
			'name'     => 'title_text_shadow',
			'selector' => '{{WRAPPER}} .kform_heading .kform_title',
		) );

		$this->add_responsive_control( 'title_margin', array(
			'label'      => esc_html__( 'Margin', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_heading .kform_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'title_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_heading .kform_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - DESCRIPTION
	// ==========================================

	private function register_style_description() {
		$this->start_controls_section( 'section_style_description', array(
			'label'     => esc_html__( 'Description', 'kdnaforms' ),
			'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
			'condition' => array( 'show_description' => 'yes' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'description_typography',
			'selector' => '{{WRAPPER}} .kform_heading .kform_description',
		) );

		$this->add_control( 'description_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_heading .kform_description' => 'color: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'description_alignment', array(
			'label'   => esc_html__( 'Alignment', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => array(
				'left'   => array( 'title' => esc_html__( 'Left', 'kdnaforms' ), 'icon' => 'eicon-text-align-left' ),
				'center' => array( 'title' => esc_html__( 'Center', 'kdnaforms' ), 'icon' => 'eicon-text-align-center' ),
				'right'  => array( 'title' => esc_html__( 'Right', 'kdnaforms' ), 'icon' => 'eicon-text-align-right' ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kform_heading .kform_description' => 'text-align: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'description_margin', array(
			'label'      => esc_html__( 'Margin', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_heading .kform_description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - LABELS
	// ==========================================

	private function register_style_labels() {
		$this->start_controls_section( 'section_style_labels', array(
			'label' => esc_html__( 'Labels', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'label_typography',
			'selector' => '{{WRAPPER}} .kfield_label label, {{WRAPPER}} .kfield_label',
		) );

		$this->add_control( 'label_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kfield_label label, {{WRAPPER}} .kfield_label' => 'color: {{VALUE}};',
			),
		) );

		$this->add_control( 'required_color', array(
			'label'     => esc_html__( 'Required Indicator Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kfield_required' => 'color: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'label_margin', array(
			'label'      => esc_html__( 'Margin', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kfield_label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'label_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kfield_label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - SUB-LABELS
	// ==========================================

	private function register_style_sub_labels() {
		$this->start_controls_section( 'section_style_sub_labels', array(
			'label' => esc_html__( 'Sub-Labels', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'sub_label_typography',
			'selector' => '{{WRAPPER}} .kform_body .kinput_complex label, {{WRAPPER}} .kform_body .kfield_description',
		) );

		$this->add_control( 'sub_label_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kinput_complex label, {{WRAPPER}} .kform_body .kfield_description' => 'color: {{VALUE}};',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - INPUT FIELDS
	// ==========================================

	private function register_style_inputs() {
		$this->start_controls_section( 'section_style_inputs', array(
			'label' => esc_html__( 'Input Fields', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'input_typography',
			'selector' => '{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])',
		) );

		$this->start_controls_tabs( 'input_style_tabs' );

		// Normal state
		$this->start_controls_tab( 'input_normal', array(
			'label' => esc_html__( 'Normal', 'kdnaforms' ),
		) );

		$this->add_control( 'input_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])' => 'color: {{VALUE}};',
			),
		) );

		$this->add_control( 'input_background', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])' => 'background-color: {{VALUE}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'input_border',
			'selector' => '{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])',
		) );

		$this->add_responsive_control( 'input_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'input_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])',
		) );

		$this->end_controls_tab();

		// Focus state
		$this->start_controls_tab( 'input_focus', array(
			'label' => esc_html__( 'Focus', 'kdnaforms' ),
		) );

		$this->add_control( 'input_focus_border_color', array(
			'label'     => esc_html__( 'Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"]):focus' => 'border-color: {{VALUE}};',
			),
		) );

		$this->add_control( 'input_focus_background', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"]):focus' => 'background-color: {{VALUE}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'input_focus_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"]):focus',
		) );

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control( 'input_placeholder_color', array(
			'label'     => esc_html__( 'Placeholder Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'separator' => 'before',
			'selectors' => array(
				'{{WRAPPER}} .kform_body input::placeholder' => 'color: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'input_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'input_height', array(
			'label'      => esc_html__( 'Height', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 20, 'max' => 100 ),
				'em' => array( 'min' => 1, 'max' => 6 ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])' => 'height: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_control( 'input_transition', array(
			'label'      => esc_html__( 'Transition Duration (ms)', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 1000, 'step' => 50 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body input:not([type="radio"]):not([type="checkbox"]):not([type="submit"]):not([type="button"]):not([type="image"]):not([type="file"]):not([type="hidden"])' => 'transition: all {{SIZE}}ms ease;',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - TEXTAREA
	// ==========================================

	private function register_style_textarea() {
		$this->start_controls_section( 'section_style_textarea', array(
			'label' => esc_html__( 'Textarea', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'textarea_typography',
			'selector' => '{{WRAPPER}} .kform_body textarea',
		) );

		$this->start_controls_tabs( 'textarea_style_tabs' );

		$this->start_controls_tab( 'textarea_normal', array( 'label' => esc_html__( 'Normal', 'kdnaforms' ) ) );

		$this->add_control( 'textarea_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body textarea' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'textarea_background', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body textarea' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'textarea_border',
			'selector' => '{{WRAPPER}} .kform_body textarea',
		) );

		$this->add_responsive_control( 'textarea_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( '{{WRAPPER}} .kform_body textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'textarea_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body textarea',
		) );

		$this->end_controls_tab();

		$this->start_controls_tab( 'textarea_focus', array( 'label' => esc_html__( 'Focus', 'kdnaforms' ) ) );

		$this->add_control( 'textarea_focus_border_color', array(
			'label'     => esc_html__( 'Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body textarea:focus' => 'border-color: {{VALUE}};' ),
		) );

		$this->add_control( 'textarea_focus_background', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body textarea:focus' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'textarea_focus_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body textarea:focus',
		) );

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control( 'textarea_placeholder_color', array(
			'label'     => esc_html__( 'Placeholder Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'separator' => 'before',
			'selectors' => array( '{{WRAPPER}} .kform_body textarea::placeholder' => 'color: {{VALUE}};' ),
		) );

		$this->add_responsive_control( 'textarea_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kform_body textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'textarea_min_height', array(
			'label'      => esc_html__( 'Min Height', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 50, 'max' => 500 ) ),
			'selectors'  => array( '{{WRAPPER}} .kform_body textarea' => 'min-height: {{SIZE}}{{UNIT}};' ),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - SELECT / DROPDOWN
	// ==========================================

	private function register_style_select() {
		$this->start_controls_section( 'section_style_select', array(
			'label' => esc_html__( 'Select / Dropdown', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'select_typography',
			'selector' => '{{WRAPPER}} .kform_body select',
		) );

		$this->add_control( 'select_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body select' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'select_background', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body select' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'select_border',
			'selector' => '{{WRAPPER}} .kform_body select',
		) );

		$this->add_responsive_control( 'select_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( '{{WRAPPER}} .kform_body select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'select_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kform_body select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'select_height', array(
			'label'      => esc_html__( 'Height', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 20, 'max' => 100 ) ),
			'selectors'  => array( '{{WRAPPER}} .kform_body select' => 'height: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'select_focus_border_color', array(
			'label'     => esc_html__( 'Focus Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body select:focus' => 'border-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'select_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body select',
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - CHECKBOX & RADIO
	// ==========================================

	private function register_style_checkbox_radio() {
		$this->start_controls_section( 'section_style_checkbox_radio', array(
			'label' => esc_html__( 'Checkbox & Radio', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$layout_options = array(
			'vertical'  => esc_html__( 'Vertical', 'kdnaforms' ),
			'inline'    => esc_html__( 'Inline (Wrap)', 'kdnaforms' ),
			'2col'      => esc_html__( '2 Columns', 'kdnaforms' ),
			'3col'      => esc_html__( '3 Columns', 'kdnaforms' ),
			'4col'      => esc_html__( '4 Columns', 'kdnaforms' ),
		);

		$layout_dict = array(
			'vertical' => 'display: flex !important; flex-direction: column !important; flex-wrap: nowrap !important;',
			'inline'   => 'display: flex !important; flex-direction: row !important; flex-wrap: wrap !important; gap: 12px 20px !important;',
			'2col'     => 'display: grid !important; grid-template-columns: repeat(2, 1fr) !important; gap: 8px 16px !important;',
			'3col'     => 'display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 8px 16px !important;',
			'4col'     => 'display: grid !important; grid-template-columns: repeat(4, 1fr) !important; gap: 8px 16px !important;',
		);

		$this->add_responsive_control( 'radio_layout', array(
			'label'   => esc_html__( 'Radio Button Layout', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => $layout_options,
			'default' => '',
			'selectors_dictionary' => $layout_dict,
			'selectors' => array(
				'{{WRAPPER}} .kfield_radio:not(.kfield_radio--image-choice)' => '{{VALUE}}',
			),
		) );

		$this->add_responsive_control( 'checkbox_layout', array(
			'label'   => esc_html__( 'Checkbox Layout', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => $layout_options,
			'default' => '',
			'selectors_dictionary' => $layout_dict,
			'selectors' => array(
				'{{WRAPPER}} .kfield_checkbox' => '{{VALUE}}',
			),
		) );

		$this->add_responsive_control( 'image_choice_layout', array(
			'label'   => esc_html__( 'Image Choice Layout', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => $layout_options,
			'default' => '',
			'selectors_dictionary' => $layout_dict,
			'selectors' => array(
				'{{WRAPPER}} .kfield--type-image_choice .kfield_radio, {{WRAPPER}} .kfield--type-image_choice .kfield_checkbox, {{WRAPPER}} .kfield_radio--image-choice' => '{{VALUE}}',
			),
		) );

		$this->add_control( 'choice_styling_heading', array(
			'label'     => esc_html__( 'Choice Styling', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
		) );

		$this->add_responsive_control( 'radio_input_label_gap', array(
			'label'      => esc_html__( 'Radio Input-Label Gap', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kfield_radio .kchoice' => 'gap: {{SIZE}}{{UNIT}} !important;',
			),
		) );

		$this->add_responsive_control( 'checkbox_input_label_gap', array(
			'label'      => esc_html__( 'Checkbox Input-Label Gap', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kfield_checkbox .kchoice' => 'gap: {{SIZE}}{{UNIT}} !important;',
			),
		) );

		$this->add_responsive_control( 'checkbox_size', array(
			'label'      => esc_html__( 'Size', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 10, 'max' => 40 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body input[type="checkbox"], {{WRAPPER}} .kform_body input[type="radio"]' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_control( 'checkbox_color', array(
			'label'     => esc_html__( 'Unchecked Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body input[type="checkbox"], {{WRAPPER}} .kform_body input[type="radio"]' => 'accent-color: {{VALUE}}; border-color: {{VALUE}};',
			),
		) );

		$this->add_control( 'checkbox_checked_color', array(
			'label'     => esc_html__( 'Checked Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_wrapper' => '--kdna-ctrl-accent-color: {{VALUE}}; --kdna-color-in-ctrl-primary: {{VALUE}}; --kdna-ctrl-choice-check-color: {{VALUE}}; --kdna-color-primary: {{VALUE}};',
				'{{WRAPPER}} .kform_wrapper input[type="checkbox"], {{WRAPPER}} .kform_wrapper input[type="radio"]' => 'accent-color: {{VALUE}} !important;',
				'{{WRAPPER}} .kform_wrapper input[type="radio"]::before' => 'background-color: {{VALUE}} !important;',
			),
		) );

		$this->add_control( 'checkbox_border_color', array(
			'label'     => esc_html__( 'Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body input[type="checkbox"], {{WRAPPER}} .kform_body input[type="radio"]' => 'outline-color: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'checkbox_border_radius', array(
			'label'      => esc_html__( 'Checkbox Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ), '%' => array( 'min' => 0, 'max' => 50 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body input[type="checkbox"]' => 'border-radius: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'checkbox_label_typography',
			'label'    => esc_html__( 'Choice Label Typography', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .kchoice_label, {{WRAPPER}} .kform_body .kchoice label',
		) );

		$this->add_control( 'checkbox_label_color', array(
			'label'     => esc_html__( 'Choice Label Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kchoice_label, {{WRAPPER}} .kform_body .kchoice label' => 'color: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'checkbox_spacing', array(
			'label'      => esc_html__( 'Spacing Between Options', 'kdnaforms' ),
			'description' => esc_html__( 'Controls radio and checkbox spacing. Use Image Choice section for image choice spacing.', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_wrapper .kfield_radio:not([class*="image-choice"]), {{WRAPPER}} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_radio, {{WRAPPER}} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_checkbox' => 'gap: {{SIZE}}{{UNIT}} !important;',
				'{{WRAPPER}} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_radio .kchoice, {{WRAPPER}} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_checkbox .kchoice' => 'margin-bottom: 0 !important;',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - IMAGE CHOICE
	// ==========================================

	private function register_style_image_choice() {
		$this->start_controls_section( 'section_style_image_choice', array(
			'label' => esc_html__( 'Image Choice', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$image_selector = '{{WRAPPER}} .kfield_radio .kchoice img, {{WRAPPER}} .kfield_checkbox .kchoice img, {{WRAPPER}} .kchoice .kfield-choice-image-wrapper img';

		$this->add_responsive_control( 'image_choice_width', array(
			'label'      => esc_html__( 'Image Width', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range'      => array(
				'px' => array( 'min' => 50, 'max' => 500 ),
				'%'  => array( 'min' => 10, 'max' => 100 ),
			),
			'selectors'  => array(
				$image_selector => 'width: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'image_choice_height', array(
			'label'      => esc_html__( 'Image Height', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array(
				'px' => array( 'min' => 50, 'max' => 500 ),
			),
			'selectors'  => array(
				$image_selector => 'height: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_control( 'image_choice_object_fit', array(
			'label'   => esc_html__( 'Image Object Fit', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => array(
				''        => esc_html__( 'Default', 'kdnaforms' ),
				'cover'   => esc_html__( 'Cover', 'kdnaforms' ),
				'contain' => esc_html__( 'Contain', 'kdnaforms' ),
				'fill'    => esc_html__( 'Fill', 'kdnaforms' ),
				'none'    => esc_html__( 'None', 'kdnaforms' ),
			),
			'default'   => '',
			'selectors' => array(
				$image_selector => 'object-fit: {{VALUE}};',
			),
		) );

		$this->add_responsive_control( 'image_choice_border_radius', array(
			'label'      => esc_html__( 'Image Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array(
				$image_selector => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'image_choice_border',
			'label'    => esc_html__( 'Image Border', 'kdnaforms' ),
			'selector' => $image_selector,
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'image_choice_box_shadow',
			'label'    => esc_html__( 'Image Box Shadow', 'kdnaforms' ),
			'selector' => $image_selector,
		) );

		$this->add_responsive_control( 'image_choice_spacing', array(
			'label'      => esc_html__( 'Spacing Between Image Choices', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 50 ),
			),
			'selectors'  => array(
				'{{WRAPPER}} .kform_wrapper .kfield--type-image_choice .kfield_radio, {{WRAPPER}} .kform_wrapper .kfield--type-image_choice .kfield_checkbox, {{WRAPPER}} .kform_wrapper .kfield_radio--image-choice' => 'gap: {{SIZE}}{{UNIT}} !important;',
				'{{WRAPPER}} .kform_wrapper .kfield--type-image_choice .kchoice' => 'margin: 0 !important; padding: 0 !important;',
			),
		) );

		$this->add_responsive_control( 'image_choice_img_to_radio_gap', array(
			'label'      => esc_html__( 'Image to Radio/Label Gap', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
			'default'    => array( 'size' => 10, 'unit' => 'px' ),
			'selectors'  => array(
				'{{WRAPPER}} .kfield--type-image_choice .kfield-image-choice-wrapper-inner' => 'margin-top: {{SIZE}}{{UNIT}} !important;',
			),
		) );

		$this->add_responsive_control( 'image_choice_input_label_gap', array(
			'label'      => esc_html__( 'Radio/Label Text Gap', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
			'default'    => array( 'size' => 6, 'unit' => 'px' ),
			'selectors'  => array(
				'{{WRAPPER}} .kfield--type-image_choice .kfield-image-choice-wrapper-inner .kform-field-label' => 'margin-left: {{SIZE}}{{UNIT}} !important;',
			),
		) );

		$selected_image_selector = '{{WRAPPER}} .kchoice input:checked + label img, {{WRAPPER}} .kchoice input:checked ~ .kfield-choice-image-wrapper img';

		$this->add_control( 'image_choice_selected_border_color', array(
			'label'     => esc_html__( 'Selected Image Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				$selected_image_selector => 'border-color: {{VALUE}} !important;',
			),
			'separator' => 'before',
		) );

		$this->add_responsive_control( 'image_choice_selected_opacity', array(
			'label'      => esc_html__( 'Selected Image Opacity', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ),
			),
			'selectors'  => array(
				$selected_image_selector => 'opacity: {{SIZE}};',
			),
		) );

		$this->add_control( 'image_choice_selected_tick_bg_color', array(
			'label'     => esc_html__( 'Selected Tick Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kfield--type-image_choice .kchoice:has(input:checked)::after' => 'background-color: {{VALUE}} !important;',
			),
		) );

		$this->add_control( 'image_choice_selected_tick_color', array(
			'label'     => esc_html__( 'Selected Tick Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kfield--type-image_choice .kchoice:has(input:checked)::after' => 'color: {{VALUE}} !important;',
			),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - FILE UPLOAD
	// ==========================================

	private function register_style_file_upload() {
		$this->start_controls_section( 'section_style_file_upload', array(
			'label' => esc_html__( 'File Upload', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'file_button_typography',
			'label'    => esc_html__( 'Button Typography', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .kform_fileupload_rules, {{WRAPPER}} .kform_body .button.kform_button_select_files',
		) );

		$this->start_controls_tabs( 'file_upload_tabs' );

		$this->start_controls_tab( 'file_upload_normal', array( 'label' => esc_html__( 'Normal', 'kdnaforms' ) ) );

		$this->add_control( 'file_button_color', array(
			'label'     => esc_html__( 'Button Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .button.kform_button_select_files' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'file_button_bg', array(
			'label'     => esc_html__( 'Button Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .button.kform_button_select_files' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'file_button_border',
			'selector' => '{{WRAPPER}} .kform_body .button.kform_button_select_files',
		) );

		$this->end_controls_tab();

		$this->start_controls_tab( 'file_upload_hover', array( 'label' => esc_html__( 'Hover', 'kdnaforms' ) ) );

		$this->add_control( 'file_button_hover_color', array(
			'label'     => esc_html__( 'Button Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .button.kform_button_select_files:hover' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'file_button_hover_bg', array(
			'label'     => esc_html__( 'Button Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .button.kform_button_select_files:hover' => 'background-color: {{VALUE}};' ),
		) );

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control( 'file_drop_area_bg', array(
			'label'     => esc_html__( 'Drop Area Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'separator' => 'before',
			'selectors' => array( '{{WRAPPER}} .kform_body .kform_drop_area' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'file_drop_area_border',
			'label'    => esc_html__( 'Drop Area Border', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .kform_drop_area',
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - SECTION BREAK
	// ==========================================

	private function register_style_section_break() {
		$this->start_controls_section( 'section_style_section_break', array(
			'label' => esc_html__( 'Section Break', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'section_title_typography',
			'label'    => esc_html__( 'Title Typography', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .ksection_title',
		) );

		$this->add_control( 'section_title_color', array(
			'label'     => esc_html__( 'Title Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .ksection_title' => 'color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'section_desc_typography',
			'label'    => esc_html__( 'Description Typography', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .ksection_description',
		) );

		$this->add_control( 'section_desc_color', array(
			'label'     => esc_html__( 'Description Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .ksection_description' => 'color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'section_break_border',
			'label'    => esc_html__( 'Bottom Border', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .ksection',
		) );

		$this->add_responsive_control( 'section_break_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kform_body .ksection' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'section_break_margin', array(
			'label'      => esc_html__( 'Margin', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kform_body .ksection' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'section_break_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body .ksection',
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - SUBMIT BUTTON
	// ==========================================

	private function register_style_submit_button() {

		// Use a short variable for the high-specificity button selector
		// Selectors for submit button - covers BOTH "End of form" (.kform_footer) and "End of last row" (#field_submit)
		$btn = '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer input[type="submit"], {{WRAPPER}} .kform_wrapper .kform_footer .kform_button, {{WRAPPER}} .kform_wrapper .kform_footer input[type="submit"], {{WRAPPER}} .kform_wrapper #field_submit input[type="submit"], {{WRAPPER}} .kform_wrapper #field_submit .kform_button, {{WRAPPER}} .kform_wrapper .kfield--type-submit input[type="submit"], {{WRAPPER}} .kform_wrapper .kfield--type-submit .kform_button';
		$btn_hover = '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer input[type="submit"]:hover, {{WRAPPER}} .kform_wrapper .kform_footer .kform_button:hover, {{WRAPPER}} .kform_wrapper .kform_footer input[type="submit"]:hover, {{WRAPPER}} .kform_wrapper #field_submit input[type="submit"]:hover, {{WRAPPER}} .kform_wrapper #field_submit .kform_button:hover, {{WRAPPER}} .kform_wrapper .kfield--type-submit input[type="submit"]:hover, {{WRAPPER}} .kform_wrapper .kfield--type-submit .kform_button:hover';

		$this->start_controls_section( 'section_style_submit', array(
			'label' => esc_html__( 'Submit Button', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_responsive_control( 'submit_gap_above', array(
			'label'      => esc_html__( 'Gap Above Button', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 100 ),
				'em' => array( 'min' => 0, 'max' => 6 ),
			),
			'selectors' => array(
				// The submit button area: both the inline #field_submit AND the .kform_footer
				'{{WRAPPER}} .kform_wrapper .kform-footer, {{WRAPPER}} .kform_wrapper .kform_footer, {{WRAPPER}} .kform_wrapper.kform-theme .kform_footer, {{WRAPPER}} .kform_wrapper.kform-theme--framework .kform_footer, {{WRAPPER}} .kform_wrapper.kform-theme .kdnaform_page_footer' => 'margin-top: {{SIZE}}{{UNIT}} !important; margin-bottom: 0 !important; padding: 0 !important;',
				// The hidden #field_submit kfield inside the grid - collapse it
				'{{WRAPPER}} .kform_wrapper .kfield--type-submit, {{WRAPPER}} .kform_wrapper #field_submit' => 'margin-top: {{SIZE}}{{UNIT}} !important; margin-bottom: 0 !important; padding: 0 !important; min-height: 0 !important;',
				// Remove margin from the last visible field
				'{{WRAPPER}} .kform_wrapper .kform_body .kform_fields > .kfield:nth-last-child(2)' => 'margin-bottom: 0 !important;',
			),
			'separator' => 'after',
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'submit_typography',
			'selector' => $btn,
		) );

		$this->start_controls_tabs( 'submit_tabs' );

		$this->start_controls_tab( 'submit_normal', array( 'label' => esc_html__( 'Normal', 'kdnaforms' ) ) );

		$this->add_control( 'submit_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				$btn => 'color: {{VALUE}} !important;',
				// The framework theme resolves the button's colour through
				// color: var(--kdna-local-color) <- --kdna-ctrl-btn-color-primary
				// <- --kdna-color-primary-contrast, so overriding the custom
				// property on the wrapper beats it without a specificity fight.
				//
				// That matters because the rule above cannot be relied on. When
				// the colour is picked from an Elementor global the generated CSS
				// comes out as `color: var( --e-global-color-text )` with the
				// !important dropped, the theme's rule wins, and the button is
				// white on whatever background was set. The background control
				// has always had this second route, which is why background
				// worked and text colour did not.
				'{{WRAPPER}} .kform_wrapper.kform-theme--framework' => '--kdna-ctrl-btn-color-primary: {{VALUE}};',
			),
		) );

		$this->add_control( 'submit_bg_color', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				$btn => 'background-color: {{VALUE}} !important; background-image: none !important;',
				'{{WRAPPER}} .kform_wrapper.kform-theme--framework' => '--kdna-ctrl-btn-bg-color-primary: {{VALUE}}; --kdna-color-primary: {{VALUE}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'submit_border',
			'selector' => $btn,
		) );

		$this->add_responsive_control( 'submit_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( $btn => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'submit_box_shadow',
			'selector' => $btn,
		) );

		$this->end_controls_tab();

		$this->start_controls_tab( 'submit_hover', array( 'label' => esc_html__( 'Hover', 'kdnaforms' ) ) );

		$this->add_control( 'submit_hover_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				$btn_hover => 'color: {{VALUE}} !important;',
				'{{WRAPPER}} .kform_wrapper.kform-theme--framework' => '--kdna-ctrl-btn-color-hover-primary: {{VALUE}};',
			),
		) );

		$this->add_control( 'submit_hover_bg_color', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				$btn_hover => 'background-color: {{VALUE}} !important; background-image: none !important;',
				'{{WRAPPER}} .kform_wrapper.kform-theme--framework' => '--kdna-ctrl-btn-bg-color-hover-primary: {{VALUE}};',
			),
		) );

		$this->add_control( 'submit_hover_border_color', array(
			'label'     => esc_html__( 'Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				$btn_hover => 'border-color: {{VALUE}} !important;',
				'{{WRAPPER}} .kform_wrapper.kform-theme--framework' => '--kdna-ctrl-btn-border-color-hover-primary: {{VALUE}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'submit_hover_box_shadow',
			'selector' => $btn_hover,
		) );

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control( 'submit_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'separator'  => 'before',
			'selectors'  => array( $btn => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;' ),
		) );

		$this->add_control( 'submit_width', array(
			'label'   => esc_html__( 'Width', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::SELECT,
			'options' => array(
				'auto' => esc_html__( 'Auto', 'kdnaforms' ),
				'100%' => esc_html__( 'Full Width', 'kdnaforms' ),
			),
			'default'   => 'auto',
			'selectors' => array( $btn => 'width: {{VALUE}} !important;' ),
		) );

		$this->add_responsive_control( 'submit_alignment', array(
			'label'   => esc_html__( 'Alignment', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => array(
				'left'   => array( 'title' => esc_html__( 'Left', 'kdnaforms' ), 'icon' => 'eicon-text-align-left' ),
				'center' => array( 'title' => esc_html__( 'Center', 'kdnaforms' ), 'icon' => 'eicon-text-align-center' ),
				'right'  => array( 'title' => esc_html__( 'Right', 'kdnaforms' ), 'icon' => 'eicon-text-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}} .kform_wrapper .kform_footer, {{WRAPPER}} .kform_wrapper.kform-theme .kform_footer, {{WRAPPER}} .kform_wrapper #field_submit, {{WRAPPER}} .kform_wrapper .kfield--type-submit' => 'text-align: {{VALUE}};' ),
		) );

		$this->add_control( 'submit_transition', array(
			'label'     => esc_html__( 'Transition Duration (ms)', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 1000, 'step' => 50 ) ),
			'selectors' => array( $btn => 'transition: all {{SIZE}}ms ease !important;' ),
		) );

		$this->add_responsive_control( 'submit_vertical_align', array(
			'label'   => esc_html__( 'Vertical Alignment', 'kdnaforms' ),
			'type'    => \Elementor\Controls_Manager::CHOOSE,
			'options' => array(
				'flex-start' => array( 'title' => esc_html__( 'Top', 'kdnaforms' ), 'icon' => 'eicon-v-align-top' ),
				'center'     => array( 'title' => esc_html__( 'Middle', 'kdnaforms' ), 'icon' => 'eicon-v-align-middle' ),
				'flex-end'   => array( 'title' => esc_html__( 'Bottom', 'kdnaforms' ), 'icon' => 'eicon-v-align-bottom' ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kform_wrapper #field_submit, {{WRAPPER}} .kform_wrapper .kfield--type-submit' => 'display: flex !important; align-items: {{VALUE}} !important;',
			),
			'description' => esc_html__( 'Align the inline submit button vertically within its grid cell. Use "Bottom" to align with input fields.', 'kdnaforms' ),
		) );

		$this->add_responsive_control( 'submit_margin_top', array(
			'label'      => esc_html__( 'Top Offset', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => -50, 'max' => 50 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_wrapper #field_submit .kform_button, {{WRAPPER}} .kform_wrapper #field_submit input[type="submit"], {{WRAPPER}} .kform_wrapper .kfield--type-submit .kform_button, {{WRAPPER}} .kform_wrapper .kfield--type-submit input[type="submit"]' => 'margin-top: {{SIZE}}{{UNIT}} !important;',
			),
			'description' => esc_html__( 'Fine-tune the button position. Use negative values to move up.', 'kdnaforms' ),
		) );

		$this->add_control( 'submit_shrink_to_fit', array(
			'label'        => esc_html__( 'Shrink Submit to Fit Button', 'kdnaforms' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'Yes', 'kdnaforms' ),
			'label_off'    => esc_html__( 'No', 'kdnaforms' ),
			'return_value' => 'yes',
			'default'      => '',
			'prefix_class' => 'kdna-shrink-submit-',
			'description'  => esc_html__( 'Switch the field row to flex layout so the submit cell sizes to the button and other fields fill remaining space.', 'kdnaforms' ),
		) );

		$this->end_controls_section();
	}
	// ==========================================

	/**
	 * Icon on the submit button, with the rotate-on-hover animation.
	 *
	 * The icon can only live inside the button if the button is an element that
	 * accepts children. The form renders <input type="submit">, which accepts
	 * neither child nodes nor ::before/::after, so choosing an icon here swaps
	 * it for <button type="submit"> carrying the same id, classes and submission
	 * attributes. Nothing changes for a form with no icon set.
	 *
	 * @since 3.6.0
	 *
	 * @return void
	 */
	private function register_style_submit_icon() {

		$icon  = '{{WRAPPER}} .kdna-sbi__icon';
		$glyph = '{{WRAPPER}} .kdna-sbi__icon > i, {{WRAPPER}} .kdna-sbi__icon > svg';

		$this->start_controls_section( 'section_style_submit_icon', array(
			'label' => esc_html__( 'Submit Button Icon', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'submit_icon', array(
			'label'       => esc_html__( 'Icon', 'kdnaforms' ),
			'type'        => \Elementor\Controls_Manager::ICONS,
			'description' => esc_html__( 'Leave empty for no icon. Choosing one renders the submit button as a <button> so the icon can sit inside it.', 'kdnaforms' ),
		) );

		$this->add_control( 'submit_icon_position', array(
			'label'     => esc_html__( 'Icon Position', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::CHOOSE,
			'default'   => 'after',
			'options'   => array(
				'before' => array( 'title' => esc_html__( 'Before', 'kdnaforms' ), 'icon' => 'eicon-h-align-left' ),
				'after'  => array( 'title' => esc_html__( 'After', 'kdnaforms' ), 'icon' => 'eicon-h-align-right' ),
			),
			'toggle'    => false,
			'condition' => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_responsive_control( 'submit_icon_size', array(
			'label'      => esc_html__( 'Icon Size', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 8, 'max' => 80 ),
				'em' => array( 'min' => 0.5, 'max' => 5, 'step' => 0.1 ),
			),
			'selectors'  => array(
				$icon  => 'font-size: {{SIZE}}{{UNIT}};',
				$glyph => 'width: 1em; height: 1em;',
			),
			'condition'  => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_responsive_control( 'submit_icon_gap', array(
			'label'      => esc_html__( 'Gap From Text', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 60 ),
				'em' => array( 'min' => 0, 'max' => 4, 'step' => 0.1 ),
			),
			'default'    => array( 'size' => 8, 'unit' => 'px' ),
			'selectors'  => array(
				'{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-gap: {{SIZE}}{{UNIT}};',
			),
			'condition'  => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_control( 'submit_icon_color', array(
			'label'       => esc_html__( 'Icon Color', 'kdnaforms' ),
			'type'        => \Elementor\Controls_Manager::COLOR,
			'description' => esc_html__( 'Leave empty to follow the button text colour.', 'kdnaforms' ),
			'selectors'   => array(
				$icon  => 'color: {{VALUE}};',
				$glyph => 'fill: {{VALUE}};',
			),
			'condition'   => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_control( 'submit_icon_hover_color', array(
			'label'     => esc_html__( 'Icon Hover Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kdna-sbi:hover .kdna-sbi__icon' => 'color: {{VALUE}};',
				'{{WRAPPER}} .kdna-sbi:hover .kdna-sbi__icon > svg' => 'fill: {{VALUE}};',
			),
			'condition' => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_control( 'submit_icon_anim_heading', array(
			'label'     => esc_html__( 'Icon Animation', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
			'condition' => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_control( 'submit_icon_anim_enable', array(
			'label'        => esc_html__( 'Enable Icon Animation', 'kdnaforms' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'label_on'     => esc_html__( 'On', 'kdnaforms' ),
			'label_off'    => esc_html__( 'Off', 'kdnaforms' ),
			'return_value' => 'yes',
			'default'      => '',
			'description'  => esc_html__( 'Animates the icon when the button is hovered or keyboard focused.', 'kdnaforms' ),
			'condition'    => array( 'submit_icon[value]!' => '' ),
		) );

		$this->add_control( 'submit_icon_anim_type', array(
			'label'     => esc_html__( 'Animation', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::SELECT,
			'default'   => 'rotate',
			'options'   => array(
				'rotate' => esc_html__( 'Rotate', 'kdnaforms' ),
				'slide'  => esc_html__( 'Slide Along', 'kdnaforms' ),
				'grow'   => esc_html__( 'Grow', 'kdnaforms' ),
			),
			'condition' => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes' ),
		) );

		$this->add_control( 'submit_icon_anim_rest_angle', array(
			'label'      => esc_html__( 'Resting Angle', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'deg' ),
			'range'      => array( 'deg' => array( 'min' => -360, 'max' => 360, 'step' => 1 ) ),
			'default'    => array( 'size' => -45, 'unit' => 'deg' ),
			'selectors'  => array( '{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-rest-angle: {{SIZE}}deg;' ),
			'condition'  => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes', 'submit_icon_anim_type' => 'rotate' ),
		) );

		$this->add_control( 'submit_icon_anim_hover_angle', array(
			'label'      => esc_html__( 'Hover Angle', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'deg' ),
			'range'      => array( 'deg' => array( 'min' => -360, 'max' => 360, 'step' => 1 ) ),
			'default'    => array( 'size' => 0, 'unit' => 'deg' ),
			'selectors'  => array( '{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-hover-angle: {{SIZE}}deg;' ),
			'condition'  => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes', 'submit_icon_anim_type' => 'rotate' ),
		) );

		$this->add_control( 'submit_icon_anim_distance', array(
			'label'      => esc_html__( 'Slide Distance', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 40 ),
				'em' => array( 'min' => 0, 'max' => 3, 'step' => 0.1 ),
			),
			'default'    => array( 'size' => 6, 'unit' => 'px' ),
			'selectors'  => array( '{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-slide: {{SIZE}}{{UNIT}};' ),
			'condition'  => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes', 'submit_icon_anim_type' => 'slide' ),
		) );

		$this->add_control( 'submit_icon_anim_scale', array(
			'label'      => esc_html__( 'Hover Scale', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'range'      => array( 'px' => array( 'min' => 1, 'max' => 3, 'step' => 0.05 ) ),
			'default'    => array( 'size' => 1.25 ),
			'selectors'  => array( '{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-scale: {{SIZE}};' ),
			'condition'  => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes', 'submit_icon_anim_type' => 'grow' ),
		) );

		$this->add_control( 'submit_icon_anim_duration', array(
			'label'     => esc_html__( 'Animation Duration (ms)', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 3000, 'step' => 50 ) ),
			'default'   => array( 'size' => 300 ),
			'selectors' => array( '{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-duration: {{SIZE}}ms;' ),
			'condition' => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes' ),
		) );

		$this->add_control( 'submit_icon_anim_easing', array(
			'label'     => esc_html__( 'Easing', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::SELECT,
			'default'   => 'ease',
			'options'   => array(
				'ease'                              => esc_html__( 'Ease', 'kdnaforms' ),
				'ease-in'                           => esc_html__( 'Ease In', 'kdnaforms' ),
				'ease-out'                          => esc_html__( 'Ease Out', 'kdnaforms' ),
				'ease-in-out'                       => esc_html__( 'Ease In Out', 'kdnaforms' ),
				'linear'                            => esc_html__( 'Linear', 'kdnaforms' ),
				'cubic-bezier(0.34, 1.56, 0.64, 1)' => esc_html__( 'Overshoot (Springy)', 'kdnaforms' ),
			),
			'selectors' => array( '{{WRAPPER}} .kdna-sbi' => '--kdna-sbi-easing: {{VALUE}};' ),
			'condition' => array( 'submit_icon[value]!' => '', 'submit_icon_anim_enable' => 'yes' ),
		) );

		$this->end_controls_section();
	}

	private function register_style_prev_next_buttons() {
		$this->start_controls_section( 'section_style_prev_next', array(
			'label' => esc_html__( 'Previous / Next Buttons', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'prev_next_heading_prev', array(
			'label' => esc_html__( 'Previous Button', 'kdnaforms' ),
			'type'  => \Elementor\Controls_Manager::HEADING,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'prev_typography',
			'selector' => '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button',
		) );

		$this->add_control( 'prev_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'prev_bg_color', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'prev_border',
			'selector' => '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button',
		) );

		$this->add_responsive_control( 'prev_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'prev_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_control( 'prev_hover_text_color', array(
			'label'     => esc_html__( 'Hover Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button:hover' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'prev_hover_bg', array(
			'label'     => esc_html__( 'Hover Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_previous_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_previous_button:hover' => 'background-color: {{VALUE}};' ),
		) );

		// Next button
		$this->add_control( 'prev_next_heading_next', array(
			'label'     => esc_html__( 'Next Button', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::HEADING,
			'separator' => 'before',
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'next_typography',
			'selector' => '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button',
		) );

		$this->add_control( 'next_text_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'next_bg_color', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'next_border',
			'selector' => '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button',
		) );

		$this->add_responsive_control( 'next_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'next_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_control( 'next_hover_text_color', array(
			'label'     => esc_html__( 'Hover Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button:hover' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'next_hover_bg', array(
			'label'     => esc_html__( 'Hover Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_wrapper.kform-theme .kform_footer .kform_next_button, {{WRAPPER}} .kform_wrapper .kform_footer .kform_next_button:hover' => 'background-color: {{VALUE}};' ),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - VALIDATION ERRORS
	// ==========================================

	private function register_style_validation() {
		$this->start_controls_section( 'section_style_validation', array(
			'label' => esc_html__( 'Validation Errors', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'validation_msg_typography',
			'label'    => esc_html__( 'Message Typography', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .kform_validation_errors, {{WRAPPER}} .kform_body .validation_message',
		) );

		$this->add_control( 'validation_msg_color', array(
			'label'     => esc_html__( 'Message Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kform_validation_errors, {{WRAPPER}} .kform_body .validation_message' => 'color: {{VALUE}};',
			),
		) );

		$this->add_control( 'validation_msg_bg', array(
			'label'     => esc_html__( 'Message Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kform_validation_errors' => 'background-color: {{VALUE}};',
			),
		) );

		$this->add_control( 'validation_field_border_color', array(
			'label'     => esc_html__( 'Error Field Border Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kfield_error input, {{WRAPPER}} .kform_body .kfield_error textarea, {{WRAPPER}} .kform_body .kfield_error select' => 'border-color: {{VALUE}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'validation_container_border',
			'label'    => esc_html__( 'Container Border', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .kform_validation_errors',
		) );

		$this->add_responsive_control( 'validation_container_padding', array(
			'label'      => esc_html__( 'Container Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body .kform_validation_errors' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'validation_container_border_radius', array(
			'label'      => esc_html__( 'Container Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body .kform_validation_errors' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'validation_box_shadow',
			'selector' => '{{WRAPPER}} .kform_body .kform_validation_errors',
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - PROGRESS BAR (Multi-Page)
	// ==========================================

	private function register_style_progress_bar() {
		$this->start_controls_section( 'section_style_progress_bar', array(
			'label' => esc_html__( 'Progress Bar (Multi-Page)', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'progress_bar_bg', array(
			'label'     => esc_html__( 'Bar Background', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .kform_page_steps' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_control( 'progress_bar_fill', array(
			'label'     => esc_html__( 'Progress Fill Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .kform_page_steps .kdna_step_active, {{WRAPPER}} .kform_body .percentbar_blue' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_responsive_control( 'progress_bar_height', array(
			'label'      => esc_html__( 'Bar Height', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 2, 'max' => 40 ) ),
			'selectors'  => array( '{{WRAPPER}} .kform_body .percentbar_blue' => 'height: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'progress_bar_border_radius', array(
			'label'      => esc_html__( 'Bar Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 20 ) ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_body .percentbar_blue, {{WRAPPER}} .kform_body .kform_percentage_bar' => 'border-radius: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'progress_step_typography',
			'label'    => esc_html__( 'Step Text Typography', 'kdnaforms' ),
			'selector' => '{{WRAPPER}} .kform_body .kdna_step, {{WRAPPER}} .kform_body .kform_percentage_bar_text',
		) );

		$this->add_control( 'progress_step_color', array(
			'label'     => esc_html__( 'Step Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .kdna_step, {{WRAPPER}} .kform_body .kform_percentage_bar_text' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'progress_active_step_color', array(
			'label'     => esc_html__( 'Active Step Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .kdna_step_active' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'progress_completed_step_color', array(
			'label'     => esc_html__( 'Completed Step Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kform_body .kdna_step_completed' => 'color: {{VALUE}};' ),
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - CONFIRMATION MESSAGE
	// ==========================================

	private function register_style_confirmation() {
		$this->start_controls_section( 'section_style_confirmation', array(
			'label' => esc_html__( 'Confirmation Message', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array(
			'name'     => 'confirmation_typography',
			'selector' => '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message',
		) );

		$this->add_control( 'confirmation_color', array(
			'label'     => esc_html__( 'Text Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message' => 'color: {{VALUE}};' ),
		) );

		$this->add_control( 'confirmation_bg', array(
			'label'     => esc_html__( 'Background Color', 'kdnaforms' ),
			'type'      => \Elementor\Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message' => 'background-color: {{VALUE}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array(
			'name'     => 'confirmation_border',
			'selector' => '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message',
		) );

		$this->add_responsive_control( 'confirmation_border_radius', array(
			'label'      => esc_html__( 'Border Radius', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', '%' ),
			'selectors'  => array( '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'confirmation_padding', array(
			'label'      => esc_html__( 'Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array( '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );

		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array(
			'name'     => 'confirmation_box_shadow',
			'selector' => '{{WRAPPER}} .kdna-elementor-form-wrapper .kform_confirmation_message',
		) );

		$this->end_controls_section();
	}

	// ==========================================
	// STYLE TAB - FIELD SPACING
	// ==========================================

	private function register_style_field_spacing() {
		$this->start_controls_section( 'section_style_field_spacing', array(
			'label' => esc_html__( 'Field Spacing', 'kdnaforms' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_responsive_control( 'field_row_gap', array(
			'label'      => esc_html__( 'Row Gap', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 60 ),
				'em' => array( 'min' => 0, 'max' => 4 ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kfield' => 'margin-bottom: {{SIZE}}{{UNIT}} !important;',
				'{{WRAPPER}} .kform_wrapper .kform_fields' => 'row-gap: {{SIZE}}{{UNIT}} !important;',
				'{{WRAPPER}} .kform_wrapper' => '--kdna-field-gap-y: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'field_column_gap', array(
			'label'      => esc_html__( 'Column Gap (Multi-column)', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px', 'em' ),
			'range'      => array(
				'px' => array( 'min' => 0, 'max' => 60 ),
				'em' => array( 'min' => 0, 'max' => 4 ),
			),
			'selectors' => array(
				'{{WRAPPER}} .kform_body .kform_fields' => 'column-gap: {{SIZE}}{{UNIT}} !important;',
				'{{WRAPPER}} .kform_body .kfield--width-half' => 'padding-right: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .kform_wrapper' => '--kdna-field-gap-x: {{SIZE}}{{UNIT}};',
			),
		) );

		$this->add_responsive_control( 'footer_margin', array(
			'label'      => esc_html__( 'Button Area Margin', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_wrapper .kform_footer, {{WRAPPER}} .kform_wrapper.kform-theme .kform_footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
			),
		) );

		$this->add_responsive_control( 'footer_padding', array(
			'label'      => esc_html__( 'Button Area Padding', 'kdnaforms' ),
			'type'       => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em' ),
			'selectors'  => array(
				'{{WRAPPER}} .kform_wrapper .kform_footer, {{WRAPPER}} .kform_wrapper.kform-theme .kform_footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
			),
		) );

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$form_id  = absint( $settings['form_id'] );

		if ( empty( $form_id ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div class="kdna-elementor-form-placeholder" style="padding:40px;text-align:center;background:#f5f5f5;border:2px dashed #ccc;border-radius:8px;">';
				echo '<p style="font-size:16px;color:#666;">' . esc_html__( 'Please select a KDNA Form from the widget settings.', 'kdnaforms' ) . '</p>';
				echo '</div>';
			}
			return;
		}

		$show_title       = $settings['show_title'] === 'yes';
		$show_description = $settings['show_description'] === 'yes';
		$use_ajax         = $settings['use_ajax'] === 'yes';
		$tab_index        = absint( $settings['tab_index'] );
		$custom_class     = sanitize_html_class( $settings['custom_class'] ?? '' );

		$wrapper_classes = array( 'kdna-elementor-form-wrapper' );
		if ( ! empty( $custom_class ) ) {
			$wrapper_classes[] = $custom_class;
		}

		echo '<div class="' . esc_attr( implode( ' ', $wrapper_classes ) ) . '">';

		// Force critical styles inline since the CSS file may not load
		$widget_selector = '.elementor-element-' . $this->get_id();
		$inline_css = '';

		// Checked color - override ALL theme CSS variables for radio/checkbox
		$checked_color = $settings['checkbox_checked_color'] ?? '';
		if ( ! empty( $checked_color ) ) {
			$inline_css .= "{$widget_selector} .kform_wrapper { --kdna-ctrl-accent-color: {$checked_color}; --kdna-color-in-ctrl-primary: {$checked_color}; --kdna-ctrl-choice-check-color: {$checked_color}; --kdna-color-primary: {$checked_color}; }";
			$inline_css .= "{$widget_selector} .kform_wrapper input[type='checkbox'], {$widget_selector} .kform_wrapper input[type='radio'] { accent-color: {$checked_color} !important; }";
			$inline_css .= "{$widget_selector} .kform_wrapper input[type='radio']::before { background-color: {$checked_color} !important; }";
			$inline_css .= "{$widget_selector} .kform_wrapper input[type='checkbox']::before { color: {$checked_color} !important; }";
		}

		// Spacing between options - radio and checkbox only (NOT image choice)
		$spacing = $settings['checkbox_spacing']['size'] ?? '';
		if ( $spacing !== '' ) {
			$unit = $settings['checkbox_spacing']['unit'] ?? 'px';
			$inline_css .= "{$widget_selector} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_radio, {$widget_selector} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_checkbox { gap: {$spacing}{$unit} !important; }";
			$inline_css .= "{$widget_selector} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_radio .kchoice, {$widget_selector} .kform_wrapper .kfield:not(.kfield--type-image_choice) .kfield_checkbox .kchoice { margin-bottom: 0 !important; }";
		}

		// Focus color
		$focus_color = $settings['global_focus_color'] ?? '';
		if ( ! empty( $focus_color ) ) {
			$inline_css .= "{$widget_selector} .kform_wrapper input:focus, {$widget_selector} .kform_wrapper textarea:focus, {$widget_selector} .kform_wrapper select:focus { border-color: {$focus_color} !important; box-shadow: 0 0 0 3px rgba(0,0,0,0.1) !important; }";
		}

		// Accent color
		$accent_color = $settings['global_accent_color'] ?? '';
		if ( ! empty( $accent_color ) ) {
			$inline_css .= "{$widget_selector} .kform_wrapper { --kdna-color-primary: {$accent_color}; }";
		}

		// Layouts - output CSS with responsive media queries
		$layout_map = array(
			'radio_layout' => '.kfield_radio:not(.kfield_radio--image-choice)',
			'checkbox_layout' => '.kfield_checkbox',
			'image_choice_layout' => '.kfield--type-image_choice .kfield_radio, ' . $widget_selector . ' .kfield--type-image_choice .kfield_checkbox',
		);

		// Get Elementor breakpoints
		$breakpoints = \Elementor\Plugin::$instance->breakpoints->get_breakpoints_config();
		$tablet_max = isset( $breakpoints['md'] ) ? $breakpoints['md']['value'] : 1024;
		$mobile_max = isset( $breakpoints['sm'] ) ? $breakpoints['sm']['value'] : 767;

		// Helper to generate layout CSS for a value
		$get_layout_css = function( $selector, $val ) {
			if ( $val === 'vertical' ) {
				return "{$selector} { display: flex !important; flex-direction: column !important; flex-wrap: nowrap !important; }";
			} elseif ( $val === 'inline' ) {
				return "{$selector} { display: flex !important; flex-direction: row !important; flex-wrap: wrap !important; gap: 12px 20px !important; }";
			} elseif ( $val === '2col' ) {
				return "{$selector} { display: grid !important; grid-template-columns: repeat(2, 1fr) !important; gap: 8px 16px !important; }";
			} elseif ( $val === '3col' ) {
				return "{$selector} { display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 8px 16px !important; }";
			} elseif ( $val === '4col' ) {
				return "{$selector} { display: grid !important; grid-template-columns: repeat(4, 1fr) !important; gap: 8px 16px !important; }";
			}
			return '';
		};

		$tablet_css = '';
		$mobile_css = '';

		foreach ( $layout_map as $setting_key => $target ) {
			$full_selector = "{$widget_selector} {$target}";

			// Desktop
			$desktop_val = $settings[ $setting_key ] ?? '';
			$inline_css .= $get_layout_css( $full_selector, $desktop_val );

			// Tablet
			$tablet_val = $settings[ $setting_key . '_tablet' ] ?? '';
			if ( ! empty( $tablet_val ) ) {
				$tablet_css .= $get_layout_css( $full_selector, $tablet_val );
			}

			// Mobile
			$mobile_val = $settings[ $setting_key . '_mobile' ] ?? '';
			if ( ! empty( $mobile_val ) ) {
				$mobile_css .= $get_layout_css( $full_selector, $mobile_val );
			}
		}

		if ( ! empty( $tablet_css ) ) {
			$inline_css .= "@media (max-width: {$tablet_max}px) { {$tablet_css} }";
		}
		if ( ! empty( $mobile_css ) ) {
			$inline_css .= "@media (max-width: {$mobile_max}px) { {$mobile_css} }";
		}

		// Submit button gap above - inline CSS fallback
		$submit_gap = $settings['submit_gap_above']['size'] ?? '';
		if ( $submit_gap !== '' ) {
			$submit_gap_unit = $settings['submit_gap_above']['unit'] ?? 'px';
			$inline_css .= "{$widget_selector} .kform_wrapper .kform_footer, {$widget_selector} .kform_wrapper.kform-theme .kform_footer { margin-top: {$submit_gap}{$submit_gap_unit} !important; padding: 0 !important; margin-bottom: 0 !important; }";
			$inline_css .= "{$widget_selector} .kform_wrapper .kfield--type-submit, {$widget_selector} .kform_wrapper #field_submit { margin-top: {$submit_gap}{$submit_gap_unit} !important; margin-bottom: 0 !important; padding: 0 !important; min-height: 0 !important; }";
			$inline_css .= "{$widget_selector} .kform_wrapper .kform_body .kform_fields > .kfield:nth-last-child(2) { margin-bottom: 0 !important; }";
		}

		if ( ! empty( $inline_css ) ) {
			echo '<style>' . $inline_css . '</style>';
		}

		// Always-on: collapse the empty sublabel span on the inline submit field so it doesn't reserve trailing space.
		echo '<style>' . $widget_selector . ' .kform_wrapper #field_submit .kfield_label, ' . $widget_selector . ' .kform_wrapper #field_submit .field_sublabel_below, ' . $widget_selector . ' .kform_wrapper #field_submit .field_sublabel_above, ' . $widget_selector . ' .kform_wrapper #field_submit .kfield_description, ' . $widget_selector . ' .kform_wrapper .kfield--type-submit .kfield_label, ' . $widget_selector . ' .kform_wrapper .kfield--type-submit .field_sublabel_below, ' . $widget_selector . ' .kform_wrapper .kfield--type-submit .field_sublabel_above, ' . $widget_selector . ' .kform_wrapper .kfield--type-submit .kfield_description { display: none !important; height: 0 !important; margin: 0 !important; padding: 0 !important; }</style>';

		// Build shortcode attributes
		$shortcode_atts = array(
			'id'          => $form_id,
			'title'       => $show_title ? 'true' : 'false',
			'description' => $show_description ? 'true' : 'false',
			'ajax'        => $use_ajax ? 'true' : 'false',
			'tabindex'    => $tab_index,
		);

		$shortcode_parts = array();
		foreach ( $shortcode_atts as $key => $value ) {
			$shortcode_parts[] = $key . '="' . esc_attr( $value ) . '"';
		}

		$shortcode = '[kdnaform ' . implode( ' ', $shortcode_parts ) . ']';

		// Render the form, with the submit button icon applied around it if one
		// is configured. The filter is added and removed around this one call so
		// a second form on the page, from another widget or a shortcode, keeps
		// its own button.
		$icon_filter = $this->get_submit_icon_filter( $settings );

		if ( $icon_filter ) {
			add_filter( 'kdnaform_submit_button', $icon_filter, 10, 2 );
		}

		echo do_shortcode( $shortcode );

		if ( $icon_filter ) {
			remove_filter( 'kdnaform_submit_button', $icon_filter, 10 );
		}

		echo '</div>';
	}

	/**
	 * The filter that puts the chosen icon inside the submit button, or null
	 * when no icon is set.
	 *
	 * The form renders the button as <input type="submit">, which can hold
	 * neither child nodes nor ::before/::after, so there is nowhere to put an
	 * icon. The input is rebuilt as <button type="submit"> carrying the same id,
	 * classes, submission attributes and tabindex, with the label moved into a
	 * span beside the icon. A <button> submits identically: the original input
	 * has no name attribute, so nothing was being posted from it to lose.
	 *
	 * If the markup is not the shape this expects, the original is returned
	 * untouched. A styled button that is missing its icon is a much smaller
	 * problem than a form with no way to submit.
	 *
	 * @since 3.6.0
	 *
	 * @param array $settings The widget settings.
	 *
	 * @return callable|null
	 */
	private function get_submit_icon_filter( $settings ) {

		$icon = isset( $settings['submit_icon'] ) ? $settings['submit_icon'] : array();

		if ( empty( $icon['value'] ) || ! class_exists( '\Elementor\Icons_Manager' ) ) {
			return null;
		}

		$position = ( isset( $settings['submit_icon_position'] ) && 'before' === $settings['submit_icon_position'] ) ? 'before' : 'after';
		$animated = ! empty( $settings['submit_icon_anim_enable'] ) && 'yes' === $settings['submit_icon_anim_enable'];
		$type     = ! empty( $settings['submit_icon_anim_type'] ) ? sanitize_html_class( $settings['submit_icon_anim_type'] ) : 'rotate';

		return function ( $button_input, $form ) use ( $icon, $position, $animated, $type ) {

			if ( ! is_string( $button_input ) || false === strpos( $button_input, '<input' ) ) {
				return $button_input;
			}

			$attr = function ( $name ) use ( $button_input ) {
				return preg_match( '/\b' . preg_quote( $name, '/' ) . "=(['\"])(.*?)\\1/s", $button_input, $m ) ? $m[2] : '';
			};

			$label = $attr( 'value' );
			$class = $attr( 'class' );

			if ( '' === $class ) {
				return $button_input;
			}

			// An image button carries its label as a src, not as text. Rebuilding
			// it as a <button> would drop the image and leave a bare icon, so it
			// is left exactly as it was.
			if ( 'submit' !== $attr( 'type' ) ) {
				return $button_input;
			}

			ob_start();
			\Elementor\Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
			$icon_html = trim( ob_get_clean() );

			if ( '' === $icon_html ) {
				return $button_input;
			}

			$wrapper_class = 'kdna-sbi kdna-sbi--' . $position;

			if ( $animated ) {
				$wrapper_class .= ' kdna-sbi--anim-' . $type;
			}

			$icon_span = '<span class="kdna-sbi__icon">' . $icon_html . '</span>';
			// Already run through esc_attr() by get_form_button(), so < > & " '
			// are entities and it is safe as element content. Escaping it again
			// would turn an apostrophe into &amp;#039; on screen.
			$text_span = '' !== $label ? '<span class="kdna-sbi__text">' . $label . '</span>' : '';

			$parts = 'before' === $position ? $icon_span . $text_span : $text_span . $icon_span;

			$keep = '';
			foreach ( array( 'id', 'onclick', 'onkeypress', 'data-submission-type', 'tabindex' ) as $name ) {
				$value = $attr( $name );

				if ( '' !== $value ) {
					$keep .= sprintf( ' %s="%s"', $name, esc_attr( $value ) );
				}
			}

			return sprintf(
				'<button type="submit" class="%s"%s>%s</button>',
				esc_attr( trim( $class . ' ' . $wrapper_class ) ),
				$keep,
				$parts
			);
		};
	}

	// No content_template() - forces Elementor to always use server-side render()
	// which properly executes the shortcode and renders the actual form.
	protected function content_template() {}
}
